<?php $__env->startSection('title'); ?>
    Add Deposit
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-info open d-flex align-items-baseline justify-content-between p-2">
        <span class="search-text fw-bold me-2">نموذج اضافة حوالة</span>
        <button class="btn search-button bg-info">
            <i class="fa-solid arrow fs-4 border-0 fa-circle-chevron-down"></i>
        </button>

    </div>
    <div class=" container custom-div" style="display: block;">
        <div class="d-flex custom-div justify-content-between align-items-center py-3">
            <a type="button" href="<?php echo e(route('transfer.create')); ?>" class="btn add border text-danger">
                عملية ايداع جديدة
                <i class="fa-solid fa-plus"></i>
            </a>
            <div style="display: flex; align-items: center;">
    <!-- <a type="button" class="btn border" href="<?php echo e(route('client.transfers')); ?>">حوالاتي</a> -->
    <?php if(auth()->guard()->check()): ?>
    <?php if(auth()->user()->role === 'Admin'): ?>
        <a type="button" class="btn border" href="<?php echo e(route('transfer.index')); ?>">الحوالات</a>
    <?php else: ?>
        <a type="button" class="btn border" href="<?php echo e(route('client.transfers')); ?>">حوالاتي</a>
    <?php endif; ?>
<?php endif; ?>
    <button class="btn border" style="margin-right: 10px;">
        <i class="fa-solid fa-print"></i>
    </button>
    <span style="flex: 1;margin-right: 10px;">
        <form id="importForm" action="<?php echo e(route('transfers.import')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <label for="fileInput" class="custom-file-upload">
                <i class="fa-solid fa-upload"></i>
            </label>
            <input type="file" id="fileInput" name="file" class="form-control">
        </form>
    </span>
    <a href="<?php echo e(route('transfers.export')); ?>"> <button class="btn border"  style="margin-right: 10px;">
        <i class="fa-solid fa-download"></i>
    </button></a>
</div>

        </div>
    </div>

    <div class="container d-flex justify-content-center mt-5">
    <form method="POST" action="<?php echo e(route('transfer.store')); ?>" class="border p-4 rounded">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
        <div class="row mb-2">
            <div class="col-md-6">
                <label for="operation-type" class="form-label">نوع العملية</label>
                <select class="form-select <?php echo e($errors->has('type_id') ? 'border border-danger' : ''); ?>" name="type_id" id="operation-type">
                    <option selected disabled>اختر...</option>
                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($type->id); ?>" <?php echo e(old('type_id') == $type->id ? 'selected' : ''); ?>><?php echo e($type->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                     <p class="text-danger">*<?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-6">
                <label for="operation-number" class="form-label">رقم العملية</label>
                <input type="text" name="numberOperation" class="form-control <?php echo e($errors->has('numberOperation') ? 'border border-danger' : ''); ?>" id="operation-number" value="<?php echo e(old('numberOperation')); ?>">
                <?php $__errorArgs = ['numberOperation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger">*<?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="row mb-2">
            <div class="col-md-6">
                <label for="transferrer-name" class="form-label">اسم المحول</label>
                <input type="text" name="sender" class="form-control <?php echo e($errors->has('sender') ? 'border border-danger' : ''); ?>" id="transferrer-name" value="<?php echo e(old('sender')); ?>">
                <?php $__errorArgs = ['sender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger">*<?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-6">
                <label for="amount" class="form-label">المبلغ</label>
                <input type="text" name="mount" class="form-control <?php echo e($errors->has('mount') ? 'border border-danger' : ''); ?>" id="amount" value="<?php echo e(old('mount')); ?>">
                <?php $__errorArgs = ['mount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger">*<?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col-md-6">
                <label for="transfer-date" class="form-label">تاريخ التحويل</label>
                <input type="date" name="dateTransfer" class="form-control <?php echo e($errors->has('dateTransfer') ? 'border border-danger' : ''); ?>" id="transfer-date" value="<?php echo e(old('dateTransfer')); ?>">
                <?php $__errorArgs = ['dateTransfer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger">*<?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-6">
                <label for="bank" class="form-label">البنك</label>
                <select name="bank_id" class="form-select <?php echo e($errors->has('bank_id') ? 'border border-danger' : ''); ?>" id="bank">
                    <option selected disabled>اختر...</option>
                    <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($bank->id); ?>" <?php echo e(old('bank_id') == $bank->id ? 'selected' : ''); ?>><?php echo e($bank->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['bank_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger">*<?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="row mb-2">
            <div class="col-md-6">
                <label for="account-number" class="form-label">رقم حساب العميل</label>
                <input type="text" name="numberAccount" class="form-control <?php echo e($errors->has('numberAccount') ? 'border border-danger' : ''); ?>" id="account-number" value="<?php echo e(old('numberAccount')); ?>">
                <?php $__errorArgs = ['numberAccount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger">*<?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-6">
                <label for="source" class="form-label">مصدر الحوالة</label>
                <input type="text" name="receiver" class="form-control <?php echo e($errors->has('receiver') ? 'border border-danger' : ''); ?>" id="source" value="<?php echo e(old('receiver')); ?>">
                <?php $__errorArgs = ['receiver'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger">*<?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <button type="submit" class="btn btn-primary w-100">إضافة</button>
    </form>
    </div>

    <style>

        form{
            background: white;
        }
        .form-control,.form-select{
            border: none;
            border-bottom: 1px solid #A45EE5;
            transition: border-bottom-color 0.3s;
        }
        .btn:hover{
            background: #A45EE5;
            color: white;
        }
        /* Hide the default file input */
        input[type="file"] {
            display: none;
        }

        /* Style the custom button to look like a regular button */
        label.custom-file-upload {
            border: 1px solid #ccc;
            background-color: #f9f9f9;
            padding: 6px 12px;
            cursor: pointer;
        }

        /* Optional: Add some hover effect */
        label.custom-file-upload:hover {
            background: #A45EE5;
            color: white;
        }
    </style>


    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            $(".open").on("click", function() {
                var icon = $(this).find("i");
                if (icon.hasClass("fa-circle-chevron-down")) {
                    icon.removeClass("fa-circle-chevron-down").addClass("fa-circle-chevron-up");
                } else {
                    icon.removeClass("fa-circle-chevron-up").addClass("fa-circle-chevron-down");
                }
                $(".custom-div").toggle();
            });
        });
        $(document).ready(function () {
    // Listen for the change event on the file input
    $('#fileInput').on('change', function () {
        // Trigger form submission when a file is selected
        $('#importForm').submit();
    });
});
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\banking_Job\bank\bank-system\resources\views/client/add.blade.php ENDPATH**/ ?>